-- IDEMPIERE-3338 Document Status Indicator
-- May 4, 2017 11:35:33 AM CEST
UPDATE AD_Column SET IsUpdateable='Y',Updated=TO_TIMESTAMP('2017-05-04 11:35:33','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=212986
;

-- May 4, 2017 11:35:39 AM CEST
UPDATE AD_Column SET IsUpdateable='Y',Updated=TO_TIMESTAMP('2017-05-04 11:35:39','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=212987
;

-- May 4, 2017 11:35:45 AM CEST
UPDATE AD_Column SET IsUpdateable='Y',Updated=TO_TIMESTAMP('2017-05-04 11:35:45','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Column_ID=212988
;

SELECT register_migration_script('201705041136_IDEMPIERE-3338.sql') FROM dual
;

